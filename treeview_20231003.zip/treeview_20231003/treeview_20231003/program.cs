﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace YourNamespace
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadTreeView();
        }

        private void LoadTreeView()
        {
            string json = @"
            [
  {
    ""name"": ""Resources"",
    ""isFile"": false,
    ""isRoot"": true,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents"",
    ""fileExtension"": null,
    ""parentPath"": ""D:\\web\\certification\\files\\20230922"",
    ""size"": 903621221,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/""
  },
  {
    ""name"": ""aaa"",
    ""isFile"": false,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""fileExtension"": null,
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents"",
    ""size"": 306463476,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa""
  },
  {
    ""name"": ""bb"",
    ""isFile"": false,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""fileExtension"": null,
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 152689128,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb""
  },
  {
    ""name"": ""1ad6d2a2-392e-4c97-a9a7-d7e4caa9988c.rvt"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\1ad6d2a2-392e-4c97-a9a7-d7e4caa9988c.rvt"",
    ""fileExtension"": "".rvt"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents"",
    ""size"": 75935744,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/1ad6d2a2-392e-4c97-a9a7-d7e4caa9988c.rvt""
  },
  {
    ""name"": ""2a25a17c-7eaf-462d-beee-5d9fc409e199.ifc"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\2a25a17c-7eaf-462d-beee-5d9fc409e199.ifc"",
    ""fileExtension"": "".ifc"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents"",
    ""size"": 9851,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/2a25a17c-7eaf-462d-beee-5d9fc409e199.ifc""
  },
  {
    ""name"": ""예시_지상1층평면도.dwg"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\예시_지상1층평면도.dwg"",
    ""fileExtension"": "".dwg"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents"",
    ""size"": 456858,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/예시_지상1층평면도.dwg""
  },
  {
    ""name"": ""평가모델_링크용 외부파일(예시).zip"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\평가모델_링크용 외부파일(예시).zip"",
    ""fileExtension"": "".zip"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents"",
    ""size"": 6022670,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/평가모델_링크용 외부파일(예시).zip""
  },
  {
    ""name"": ""11d3f73e-7132-49af-8517-f4d38f5644f5.dwg"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\11d3f73e-7132-49af-8517-f4d38f5644f5.dwg"",
    ""fileExtension"": "".dwg"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 456858,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/11d3f73e-7132-49af-8517-f4d38f5644f5.dwg""
  },
  {
    ""name"": ""37d41948-aeff-497a-9659-9d8fb4d1c36a"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\37d41948-aeff-497a-9659-9d8fb4d1c36a"",
    ""fileExtension"": """",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 456858,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/37d41948-aeff-497a-9659-9d8fb4d1c36a""
  },
  {
    ""name"": ""59aa0b47-d99e-4933-b17e-149c2a76a23f.rvt"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\59aa0b47-d99e-4933-b17e-149c2a76a23f.rvt"",
    ""fileExtension"": "".rvt"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 70619136,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/59aa0b47-d99e-4933-b17e-149c2a76a23f.rvt""
  },
  {
    ""name"": ""59f0b06e-0767-4d1b-a1f5-0fd1a8b3d536.zip"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\59f0b06e-0767-4d1b-a1f5-0fd1a8b3d536.zip"",
    ""fileExtension"": "".zip"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 4500869,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/59f0b06e-0767-4d1b-a1f5-0fd1a8b3d536.zip""
  },
  {
    ""name"": ""61da67fe-9372-4d60-ac5f-62a97729a1c4"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\61da67fe-9372-4d60-ac5f-62a97729a1c4"",
    ""fileExtension"": """",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 6022670,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/61da67fe-9372-4d60-ac5f-62a97729a1c4""
  },
  {
    ""name"": ""64b7432e-56dd-4e58-922e-3c43ffa22363"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\64b7432e-56dd-4e58-922e-3c43ffa22363"",
    ""fileExtension"": """",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 95301,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/64b7432e-56dd-4e58-922e-3c43ffa22363""
  },
  {
    ""name"": ""9dee23f9-71e4-4990-ab65-a86f667bc7b5"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\9dee23f9-71e4-4990-ab65-a86f667bc7b5"",
    ""fileExtension"": """",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa"",
    ""size"": 71622656,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/9dee23f9-71e4-4990-ab65-a86f667bc7b5""
  },
  {
    ""name"": ""0715171b-8657-4503-915e-2fcc335c1b66.zip"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb\\0715171b-8657-4503-915e-2fcc335c1b66.zip"",
    ""fileExtension"": "".zip"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""size"": 6022670,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb/0715171b-8657-4503-915e-2fcc335c1b66.zip""
  },
  {
    ""name"": ""13165862-0ce7-427c-a935-b29deb2ae8ef.zip"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb\\13165862-0ce7-427c-a935-b29deb2ae8ef.zip"",
    ""fileExtension"": "".zip"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""size"": 4500869,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb/13165862-0ce7-427c-a935-b29deb2ae8ef.zip""
  },
  {
    ""name"": ""3710ce2a-b2e6-43a5-a330-9ef25bc3f2d7.rvt"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb\\3710ce2a-b2e6-43a5-a330-9ef25bc3f2d7.rvt"",
    ""fileExtension"": "".rvt"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""size"": 70615040,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb/3710ce2a-b2e6-43a5-a330-9ef25bc3f2d7.rvt""
  },
  {
    ""name"": ""42909265-798e-43a2-9d35-862db0e407a9.3dm"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb\\42909265-798e-43a2-9d35-862db0e407a9.3dm"",
    ""fileExtension"": "".3dm"",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""size"": 95301,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb/42909265-798e-43a2-9d35-862db0e407a9.3dm""
  },
  {
    ""name"": ""610b67df-3fe4-4846-ac4c-f1c7974640ed"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb\\610b67df-3fe4-4846-ac4c-f1c7974640ed"",
    ""fileExtension"": """",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""size"": 263895,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb/610b67df-3fe4-4846-ac4c-f1c7974640ed""
  },
  {
    ""name"": ""706ce367-4176-4a19-8ecb-06671375495b"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb\\706ce367-4176-4a19-8ecb-06671375495b"",
    ""fileExtension"": """",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""size"": 572217,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb/706ce367-4176-4a19-8ecb-06671375495b""
  },
  {
    ""name"": ""80508dad-5a15-4257-8381-da0a7af5d304"",
    ""isFile"": true,
    ""isRoot"": false,
    ""path"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb\\80508dad-5a15-4257-8381-da0a7af5d304"",
    ""fileExtension"": """",
    ""parentPath"": ""D:\\web\\certification\\files\\20230922\\contents\\aaa\\bb"",
    ""size"": 70619136,
    ""downloadUrl"": ""https://bim.haeahn.com/certification/files/20230922/contents/aaa/bb/80508dad-5a15-4257-8381-da0a7af5d304""
  }
]
            ";

            List<TreeNodeData> treeNodes = new List<TreeNodeData>();
            JArray jsonArray = JArray.Parse(json);

            foreach (JObject jsonObject in jsonArray)
            {
                string isroot = jsonObject["isRoot"].ToString();
                TreeNodeData node = new TreeNodeData
                {
                    Name = jsonObject["name"].ToString(),
                    Path = jsonObject["path"].ToString(),
                    IsSelected = false,
                    Icon = new BitmapImage(new Uri(@"images/file.png", UriKind.Relative)), // new BitmapImage(new Uri($"./../Images/{fileName}", UriKind.Relative));
                };
                //var uri = new Uri(@"image/qty15section3.jpg", UriKind.Relative);
                if (isroot == "True")
                {
                    treeNodes.Add(node);
                }
                string parentPath = jsonObject["parentPath"]?.ToString();
                if (!string.IsNullOrEmpty(parentPath))
                {
                    TreeNodeData parentNode = FindNodeByPath(treeNodes, parentPath);
                    if (parentNode != null)
                    {
                        parentNode.Children.Add(node);
                    }
                }
                else
                {
                    treeNodes.Add(node);
                }
            }

            treeView.ItemsSource = treeNodes;
        }

        private TreeNodeData FindNodeByPath(List<TreeNodeData> nodes, string path)
        {
            foreach (var node in nodes)
            {
                if (node.Path == path)
                {
                    return node;
                }

                var childNode = FindNodeByPath(node.Children, path);
                if (childNode != null)
                {
                    return childNode;
                }
            }

            return null;
        }

        private void DownloadSelected_Click(object sender, RoutedEventArgs e)
        {
            List<TreeNodeData> selectedNodes = GetSelectedNodes(treeView);
            foreach (TreeNodeData node in selectedNodes)
            {
                string strURL = node.DownloadUrl;
                try
                {
                    //Launch Chrome in a new window
                    System.Diagnostics.Process.Start("chrome", strURL + " --new-window");
                }
                catch
                {
                    try
                    {
                        //Chrome not found ... launch MS Edge in a new window
                        System.Diagnostics.Process.Start("msedge", "-new-window " + strURL);
                    }
                    catch
                    {
                        try
                        {
                            //Chrome not found ... launch Firefox in a new window
                            System.Diagnostics.Process.Start("firefox", "-new-window " + strURL);
                        }
                        catch
                        {
                            //WARN THE USER TO INSTALL A BROWSER...
                        }
                    }
                }
            }
        }

        private List<TreeNodeData> GetSelectedNodes(TreeView treeView)
        {
            List<TreeNodeData> selectedNodes = new List<TreeNodeData>();
            GetSelectedNodesRecursive(selectedNodes, treeView.Items);
            return selectedNodes;
        }

        private void GetSelectedNodesRecursive(List<TreeNodeData> selectedNodes, ItemCollection items)
        {
            items.
            foreach (var item in items)
            {
                if (item is TreeViewItem treeViewItem)
                {
                    TreeNodeData node = treeViewItem.DataContext as TreeNodeData;
                    if (node != null && node.IsSelected)
                    {
                        selectedNodes.Add(node);
                    }

                    GetSelectedNodesRecursive(selectedNodes, treeViewItem.Items);
                }
            }
        }

        //private List<TreeNodeData> GetSelectedNodes(ItemCollection items)
        //{
        //    List<TreeNodeData> selectedNodes = new List<TreeNodeData>();
        //    foreach (var item in items)
        //    {
        //        if (item is TreeNodeData node && node.IsSelected)
        //        {
        //            selectedNodes.Add(node);
        //        }
        //
        //        if (item is TreeViewItem treeViewItem)
        //        {
        //            selectedNodes.AddRange(GetSelectedNodes(treeViewItem.Items));
        //        }
        //    }
        //    return selectedNodes;
        //}
    }

    public class TreeNodeData
    {
        public string Name { get; set; }
        public string Path { get; set; }
        public List<TreeNodeData> Children { get; set; } = new List<TreeNodeData>();
        public bool IsSelected { get; set; }
        public string DownloadUrl { get; set; }
        public BitmapImage Icon { get; set; }
    }
}